# Changelog for VS_Code cookbook

## 0.1.0
* Initial Release
* Tested support for Windows and Ubuntu
* Untested recipe for mac_os_x family
* Add specs and integration tests
